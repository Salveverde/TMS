import Security
let greeting = "Hello there!"


      //Степень
let myNum = [(1, "a"), (2, "b"), (3, "c")]
let mapedNums: (Int) = myNum.map({$0 * $0})
    print("mapedNums")

     // Фильтр
let filted = myNum.filter({$0 % 2 == 0})
    print("filted")

    //Сортировка
try  myNum.sorted(by: <#T##((Int, String), (Int, String)) throws -> Bool#>)
    print("sortedObj")

                          
